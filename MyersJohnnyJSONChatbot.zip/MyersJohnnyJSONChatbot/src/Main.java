public class Main {

    public static void main(String[] args) {

        System.out.println("Name: Johnny Myers Jr.");
        System.out.println("Date: " + java.time.LocalDate.now());
        System.out.println("Course: Java Programming");
        System.out.println("Purpose: Console chatbot using JSON + OOP\n");

        Chatbot bot = new Chatbot();
        bot.loadData("chatdata.json");
        bot.chat();
    }
}
