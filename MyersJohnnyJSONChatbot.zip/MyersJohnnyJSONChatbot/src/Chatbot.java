import java.io.FileReader;
import java.io.IOException;
import java.util.*;

import org.json.JSONObject;
import org.json.JSONTokener;

public class Chatbot {

    private Map<String, String> knowledgeBase = new HashMap<>();
    private int learnedCount = 0;

    public void loadData(String fileName) {
        try (FileReader reader = new FileReader(fileName)) {

            JSONTokener tokener = new JSONTokener(reader);
            JSONObject json = new JSONObject(tokener);

            for (String key : json.keySet()) {
                knowledgeBase.put(key.toLowerCase(), json.getString(key));
            }

            System.out.println("Chatbot loaded successfully!");

        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("JSON error: " + e.getMessage());
        }
    }

    private List<String> findMatches(String input) {
        List<String> results = new ArrayList<>();

        for (String key : knowledgeBase.keySet()) {
            if (key.contains(input) || input.contains(key)) {
                results.add(key);
            }
        }
        return results;
    }

    public void chat() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Chatbot ready! Type 'exit' to quit.");

        while (true) {
            System.out.print("You: ");
            String input = scanner.nextLine().toLowerCase().trim();

            if (input.equals("exit") || input.equals("goodbye")) {
                System.out.println("Bot: Goodbye!");
                break;
            }

            if (knowledgeBase.containsKey(input)) {
                System.out.println("Bot: " + knowledgeBase.get(input));
            } else {
                List<String> matches = findMatches(input);

                if (!matches.isEmpty()) {
                    System.out.println("Bot (partial matches):");
                    for (String m : matches) {
                        System.out.println("- " + knowledgeBase.get(m));
                    }
                } else {
                    System.out.println("Bot: I don't know that. Teach me:");
                    String response = scanner.nextLine();

                    knowledgeBase.put(input, response);
                    learnedCount++;

                    System.out.println("Bot: Learned it!");
                }
            }
        }

        scanner.close();
        System.out.println("\nLearned items: " + learnedCount);
    }
}
